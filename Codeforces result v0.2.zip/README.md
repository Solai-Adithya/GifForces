# GifForces
Primarily a browser extension that monitors your latest submission to problems on codeforces and displays appropriate gifs so that you don't have to keep checking the submissions tab.

This project is still in development , you can expect this to be deployed in a few days.
